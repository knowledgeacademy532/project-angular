import { Component } from '@angular/core';

@Component({
  selector: 'app-service',
  templateUrl: './service.component.html',
  styleUrls: ['./service.component.css']
})
export class ServiceComponent {
  longText = `Business Analysts are a communication bridge between 
  IT and business stakeholders. Our range of specially created Business
   Analysis training provides you with the skills and knowledge needed for a successful Business Analyst career. 
  This training will develop your skill set of engaging with stakeholders to understand and respond to their requirements in changing business environments.`;
  longTextp=`PRINCE2® (PRojects In Controlled Environments) is one of the most popular project management methodologies in the world. Its focus on best practice principles and adaptable process-based approach makes it applicable to projects of all scopes and sizes within any sector.
   PRINCE2® is a credible and prominent methodology that concentrates on boosting productivity and extracting the best from resources.`;
   longTextit=`ITIL® is the world’s leading approach to IT service management. Created by the UK government and based on best practice principles,
    ITIL® features a range of certifications to help businesses align their IT services to the needs of their customers and organisation.`;
    longTextcrm=`Our CRM courses equip you with the skills to use a range of CRM systems, including Salesforce, Oracle, Microsoft and more.`;
}
